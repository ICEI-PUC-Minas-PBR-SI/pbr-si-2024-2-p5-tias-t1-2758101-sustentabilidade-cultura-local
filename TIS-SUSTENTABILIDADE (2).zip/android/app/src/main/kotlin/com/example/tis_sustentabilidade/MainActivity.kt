package com.example.tis_sustentabilidade

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
